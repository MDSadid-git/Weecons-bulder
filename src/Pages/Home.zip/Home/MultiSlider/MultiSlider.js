import React from "react";

const MultiSlider = () => {
  return (
    <>
      <p>multiSlider .............</p>
    </>
  );
};

export default MultiSlider;
