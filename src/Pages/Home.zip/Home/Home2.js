import React from "react";
import Banner from "../Home2/Banner";
import Info2 from "../Home2/Info2";
import "./Home2.css";

const Home2 = () => {
  return (
    <>
      <Banner />
      <Info2 />
    </>
  );
};

export default Home2;
