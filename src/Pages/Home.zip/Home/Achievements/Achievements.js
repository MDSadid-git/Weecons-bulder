import React from "react";
import AchievementsCard from "./AchievementsCard";

const Achievements = () => {
  const data = [
    {
      id: 1,
      title: "Successful project",
      description:
        "Construction companies often measure success based on completing projects within the agreed-upon timeline, budget, and quality standards.",
      img: "https://i.ibb.co/JKDc4dy/pic1.jpg",
    },
    {
      id: 2,
      title: "Client satisfaction",
      description:
        "A satisfied client is a testament to a construction company's ability to meet their expectations and deliver a high-quality project.",
      img: "https://i.ibb.co/42b2v3M/pic2.jpg",
    },
    {
      id: 3,
      title: "Safety records",
      description:
        "Maintaining an excellent safety record is a significant achievement in the construction industry.  ",
      img: "https://i.ibb.co/pKs0mbM/pic3.jpg",
    },
    {
      id: 4,
      title: "Employee",
      description:
        "Creating a positive work environment, investing in employee training and development,and maintaining a skilled workforce are",
      img: "https://i.ibb.co/s1vtsHB/pic4.jpg",
    },
    {
      id: 5,
      title: "Sustainable practices",
      description:
        "Construction companies are increasingly focusing on sustainability. Implementing environmentally friendly construction practices,",
      img: "https://i.ibb.co/1rfgLDH/pic5.jpg",
    },
    {
      id: 6,
      title: "Collaborations",
      description:
        "Construction companies often work in partnership with other firms, subcontractors, and suppliers. Building strong collaborative",
      img: "https://i.ibb.co/C8nR9by/pic6.jpg",
    },
  ];

  return (
    <>
      <section className="text-accent body-font">
        <div className="container px-5 py-24 mx-auto">
          <div className="flex flex-col text-center w-full mb-20 pt-14">
            <h2 className="text-secondary font-bold text-4xl uppercase relative h-auto w-full pb-1 text-center ">
              Our Grate
              <span className="text-brand"> Achievement</span>
            </h2>
            <p className="lg:w-2/3 mx-auto leading-relaxed text-textColure">
              Construction is a general term meaning the art and science to form
              objects systems organizations, and comes from Latin construction
              and Old French construction. To construct is the verb: the act of
              building, and the noun is construction.
            </p>
          </div>

          <div className="flex flex-wrap -m-4">
            {data.map((infoData) => (
              <AchievementsCard
                key={infoData.id}
                infoData={infoData}
              ></AchievementsCard>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Achievements;
